
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <stdio.h>
#include<string.h>
 
int main()
{
 
    char str[100];
    int listen_desc, comm_desc; /* Los descriptores de archivo que se van a usar */
 
    struct sockaddr_in servaddr; /* (ip, puerto) */
 
    listen_desc = socket(AF_INET, SOCK_STREAM, 0); /* Usamos una conexión TCP para mantener una conexión fiable y asegurar la entrega de mensajes, toda la información de conexión irá al descriptor*/
 
    bzero( &servaddr, sizeof(servaddr)); /* Se vacía servaddr*/
 
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = htons(INADDR_ANY);
    servaddr.sin_port = htons(22000);
 
    bind(listen_desc, (struct sockaddr *) &servaddr, sizeof(servaddr));
 
    listen(listen_desc, 10); /*Empieza a estar pendiente de conexiones, se admiten hasta 10*/
 
    comm_desc = accept(listen_desc, (struct sockaddr*) NULL, NULL); /*Acepta conexiòn de un dispositivo si es que hay en espera*/
 
    while(1)
    {
 
        bzero( str, 100);
 
        read(comm_desc,str,100); /* Se lee el mensaje del cliente */
 
        printf("-  %s",str);
 
        write(comm_desc, str, strlen(str)+1); /* Se envía el mensaje del cliente repetido*/
 
    }
}
