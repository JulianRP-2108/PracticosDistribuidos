#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <stdio.h>
#include<string.h>
 
int main(int argc,char **argv)
{
    int sockdesc,n;
    char sendline[100];
    char recvline[100];
    struct sockaddr_in servaddr; /* Se usa la estructura genérica de dirección*/
 
    sockdesc=socket(AF_INET,SOCK_STREAM,0); 
    bzero(&servaddr,sizeof servaddr);
 
    servaddr.sin_family=AF_INET;
    servaddr.sin_port=htons(22000);
 
    inet_pton(AF_INET,"localhost",&(servaddr.sin_addr)); /* Seteamos la ip del servidor en localhost que es donde lo ubicaremos y la dirección servaddr se pasa a entero*/
 
    connect(sockdesc,(struct sockaddr *)&servaddr,sizeof(servaddr)); /* Se conecta al dispositivo que tenga la dupla ip, puerto especificada en servaddr*/

 while(1)
    {
        bzero( sendline, 100);
        bzero( recvline, 100); /* Se hace un clear en sendline y recvline */
        fgets(sendline,100,stdin); /* Lee la entrada */
 
        write(sockdesc,sendline,strlen(sendline)+1);
        read(sockdesc,recvline,100);
        printf("%s",recvline);
    } 
}
